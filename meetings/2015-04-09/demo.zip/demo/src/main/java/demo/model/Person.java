package demo.model;

public interface Person {

	void setName(String name);

	String getName();

	String getDescription();

	void decorate(String decoration);

}
