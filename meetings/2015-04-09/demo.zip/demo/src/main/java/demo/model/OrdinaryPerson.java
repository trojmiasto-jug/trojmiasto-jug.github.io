package demo.model;

import org.springframework.stereotype.Component;

import demo.qualifier.NotImportant;

//@Component
//@NotImportant
public class OrdinaryPerson implements Person {

	private String name;
	protected String decoration = "";

	@Override
	public void setName(String name) {
		this.name = name;

	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public String getDescription() {
		return "ordinary person";
	}

	@Override
	public void decorate(String decoration) {
		this.decoration = decoration;

	}

	@Override
	public String toString() {
		return decoration + " " + getDescription() + ": " + getName() + " " + decoration;
	}

}
