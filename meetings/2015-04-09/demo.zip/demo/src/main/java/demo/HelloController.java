package demo;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import demo.model.City;
import demo.model.Person;
import demo.qualifier.NotImportant;
import demo.qualifier.VeryImportant;

// mvn package && java -jar target/demo-0.0.1-SNAPSHOT.jar
@RestController
public class HelloController {

	@Autowired
	@NotImportant
	private Person person;

	@Autowired
	@VeryImportant
	private Person president;

	@Value("#{nearCities.cities.?[population gt 200].![name.toUpperCase() + ' - ' + population + ' tys.']}")
	private List<String> bigCities;

	@Value("#{nearCities.cities}")
	private List<City> cities;
	
	private String navigation;
	

	@PostConstruct
	public void init() {
		president.setName("Tomasz Kowalski");
		navigation = createNavigation();
	}


	@RequestMapping("/")
	public String index() {
		return "Hello Bootstrap!" + navigation;
	}

	@RequestMapping("/person")
	public String person() {
		return person + navigation;
	}

	@RequestMapping("/president")
	public String president() {
		return president + navigation;
	}

	@RequestMapping("/cities")
	public List<City> cities() {
		return cities;
	}

	@RequestMapping("/bigCities")
	public List<String> bigCities() {
		return bigCities;
	}

	@RequestMapping(value = "decorate/{decoration}")
	public String decorate(@PathVariable String decoration) {
		if (decoration.equals("0")) {
			decoration = "";
		} 
		person.decorate(decoration);
		return (decoration.isEmpty() ? "decoration removed" : ("added decoration to person: " + decoration)) + navigation;
	}

	
	private String createNavigation() {
		StringBuilder navig = new StringBuilder("<br><br><br>");
		navig.append("<a href='/person'>person</a> ");
		navig.append("<a href='/president'>president</a> ");
		navig.append("<a href='/cities'>cities</a> ");
		navig.append("<a href='/bigCities'>bigCities</a> ");
		navig.append("<a href='/decorate/@'>decorate</a> ");
		return navig.toString();		
	}
}
