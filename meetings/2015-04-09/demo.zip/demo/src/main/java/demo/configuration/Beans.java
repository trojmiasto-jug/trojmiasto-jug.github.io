package demo.configuration;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import demo.model.City;
import demo.model.ImportantPerson;
import demo.model.NearCities;
import demo.model.OrdinaryPerson;
import demo.model.Person;
import demo.qualifier.NotImportant;
import demo.qualifier.VeryImportant;

@Configuration
public class Beans {
	
	@Bean
	@NotImportant
	public Person createPerson() {
		OrdinaryPerson person = new OrdinaryPerson();
		person.setName("Jan Iksinski");
		return person;
	}
	
}