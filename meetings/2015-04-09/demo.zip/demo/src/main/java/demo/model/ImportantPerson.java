package demo.model;

import org.springframework.stereotype.Component;

import demo.qualifier.VeryImportant;

@Component
@VeryImportant
public class ImportantPerson extends OrdinaryPerson {

	@Override
	public String getDescription() {
		return "important person";
	}

}
