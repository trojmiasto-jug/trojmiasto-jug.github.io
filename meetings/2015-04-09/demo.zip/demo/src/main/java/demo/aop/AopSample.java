package demo.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class AopSample {

	@Around("execution(public void demo.model.OrdinaryPerson.decorate(..))")
	public void tracePerson(ProceedingJoinPoint joinPoint) {
		try {
			String decoration = (String) joinPoint.getArgs()[0];
			System.out.println("*");
			System.out.println("* Decoration changed to " + decoration);
			System.out.println("*");
			joinPoint.proceed(new Object[] {decoration});
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}
}
