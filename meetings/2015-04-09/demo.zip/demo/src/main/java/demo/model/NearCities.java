package demo.model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class NearCities {

	private List<City> cities = new ArrayList<City>();
	
	public NearCities() {
		cities.add(new City("Gdańsk", 460));
		cities.add(new City("Gdynia", 248));
		cities.add(new City("Sopot", 38));
		cities.add(new City("Tczew", 61));
		cities.add(new City("Wejherowo", 50));
	}

	public NearCities(List<City> cities) {
		this.cities.addAll(cities);
	}

	public List<City> getCities() {
		return cities;
	}

}
